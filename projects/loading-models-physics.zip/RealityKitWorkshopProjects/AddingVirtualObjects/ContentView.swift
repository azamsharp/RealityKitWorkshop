//
//  ContentView.swift
//  AddingVirtualObjects
//
//  Created by Mohammad Azam on 2/13/24.
//

import SwiftUI
import RealityKit
import Combine

struct ContentView : View {
    var body: some View {
        ARViewContainer().edgesIgnoringSafeArea(.all)
    }
}

class ShoeEntity: Entity, HasModel, HasCollision {
    
    private var cancellable: AnyCancellable?
    private var onLoaded: (() -> Void)?
    
    required init(name: String) {
        super.init()
        self.name = name
        
        //generateCollisionShapes(recursive: true)
        
       
        // add physics
        //self.components[PhysicsBodyComponent.self] =
    }
    
    func load(onLoaded: (@escaping () -> Void)) {
        
        self.onLoaded = onLoaded
        
        cancellable = Entity.loadModelAsync(named: self.name)
            .sink { completion in
                switch completion {
                    case .failure(let error):
                        self.cancellable?.cancel()
                        print(error.localizedDescription)
                    case .finished:
                        break
                }
            } receiveValue: { entity in
                
                // entity is a model of a shoe
                
                entity.generateCollisionShapes(recursive: true)
                let physicsResource: PhysicsMaterialResource = .generate(friction: 10, restitution: -10)
                entity.components[PhysicsBodyComponent.self] = PhysicsBodyComponent(shapes: entity.collision!.shapes, mass: 1.0, material: physicsResource, mode: .dynamic)
                
                self.addChild(entity)
                
                Task {
                    await MainActor.run {
                        onLoaded()
                    }
                }
            }
    }
    
    required convenience init() {
        self.init(name: "shoe")
    }
    
}

class Coordinator {
    
    var arView: ARView?
    private var cancellable: AnyCancellable?
    
    @objc func tapped(_ recognizer: UITapGestureRecognizer) {
        
        guard let arView = arView else { return }
        let location = recognizer.location(in: arView)
        
        let results = arView.raycast(from: location, allowing: .estimatedPlane, alignment: .horizontal)
        if let result = results.first {
            
            let shoe = ShoeEntity(name: "shoe")
            shoe.position.y = 0.5
            shoe.load {
                let anchor = AnchorEntity(raycastResult: result)
                anchor.addChild(shoe)
                arView.scene.addAnchor(anchor)
            }
          
            
            /*
            cancellable = ModelEntity.loadAsync(named: "shoe")
                .sink { completion in
                    switch completion {
                        case .failure(let error):
                            print(error)
                        case .finished:
                            break
                    }
                } receiveValue: { entity in
                    
                  
                    let anchor = AnchorEntity(raycastResult: result)
                    entity.generateCollisionShapes(recursive: true)
                    
                    let physicsResource: PhysicsMaterialResource = .generate(friction: 10, restitution: -10)
                    
                    let collisionComponent = CollisionComponent(shapes: [.generateBox(size: [0.2, 0.2, 0.2])], mode: .default)
                    entity.components[CollisionComponent.self] = collisionComponent
                    entity.components[PhysicsBodyComponent.self] = PhysicsBodyComponent(shapes: collisionComponent.shapes, mass: 10.0, material: physicsResource, mode: .dynamic)
                    
                    entity.position.y = 0.5
                    
                    anchor.addChild(entity)
                    arView.scene.addAnchor(anchor)
                    
                    
                    //arView.installGestures(.all, for: entity)
                }
             
             */
            
            
        }
        
    }
}

struct ARViewContainer: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        arView.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped)))
        
        // add floor
        let anchor = AnchorEntity(plane: .horizontal)
        
        let floor = ModelEntity(mesh: MeshResource.generatePlane(width: 5.5, depth: 5.5), materials: [OcclusionMaterial(receivesDynamicLighting: false)])
        floor.generateCollisionShapes(recursive: true)
        floor.components[PhysicsBodyComponent.self] = PhysicsBodyComponent(massProperties: .default, material: .default, mode: .static)
        
        anchor.addChild(floor)
        arView.scene.addAnchor(anchor)
        
        context.coordinator.arView = arView
        
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
}

#Preview {
    ContentView()
}
