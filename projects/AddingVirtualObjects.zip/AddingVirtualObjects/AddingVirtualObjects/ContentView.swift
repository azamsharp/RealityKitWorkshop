//
//  ContentView.swift
//  AddingVirtualObjects
//
//  Created by Mohammad Azam on 2/13/24.
//

import SwiftUI
import RealityKit

struct ContentView : View {
    var body: some View {
        ARViewContainer().edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        // create the box mesh
        let boxMesh = MeshResource.generateBox(size: 0.3, cornerRadius: 0.003)
        // create the box entity
        let box = ModelEntity(mesh: boxMesh, materials: [SimpleMaterial(color: .purple, isMetallic: true)])
        // create the anchor
        let boxAnchor = AnchorEntity(plane: .horizontal)
        // add entity to the anchor
        boxAnchor.addChild(box)

        // add anchor to the scene
        arView.scene.addAnchor(boxAnchor)
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
}

#Preview {
    ContentView()
}
