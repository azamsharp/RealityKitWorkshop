//
//  ContentView.swift
//  AddingVirtualObjects
//
//  Created by Mohammad Azam on 2/13/24.
//

import SwiftUI
import RealityKit

struct ContentView : View {
    var body: some View {
        ARViewContainer().edgesIgnoringSafeArea(.all)
    }
}

class Coordinator {
    
    var arView: ARView?
    
    @objc func tapped(_ recognizer: UITapGestureRecognizer) {
        
        guard let arView = arView else { return }
        
        let location = recognizer.location(in: arView)
        if let entity = arView.entity(at: location) as? ModelEntity {
            entity.model?.materials = [SimpleMaterial(color: .orange, isMetallic: true)]
        }
    }
}

struct ARViewContainer: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        arView.addGestureRecognizer(UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped)))
        
        // create the box mesh
        let boxMesh = MeshResource.generateBox(size: 0.3, cornerRadius: 0.003)
        // create the box entity
        let box = ModelEntity(mesh: boxMesh, materials: [SimpleMaterial(color: .purple, isMetallic: true)])
        // make sure that the box can have shapes so it can be interacted with
        box.generateCollisionShapes(recursive: true)
        // create the anchor
        let boxAnchor = AnchorEntity(plane: .horizontal)
        // add entity to the anchor
        boxAnchor.addChild(box)

        // add anchor to the scene
        arView.scene.addAnchor(boxAnchor)
        
        context.coordinator.arView = arView
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
}

#Preview {
    ContentView()
}
