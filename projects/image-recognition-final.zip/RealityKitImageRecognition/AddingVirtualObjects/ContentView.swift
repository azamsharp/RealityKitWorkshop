//
//  ContentView.swift
//  AddingVirtualObjects
//
//  Created by Mohammad Azam on 2/13/24.
//

import SwiftUI
import RealityKit
import Combine

struct ContentView : View {
    
    var body: some View {
        VStack {
            ARViewContainer().edgesIgnoringSafeArea(.all)
        }
    }
}

class Coordinator {
    
    var arView: ARView?
    var cancellable: AnyCancellable?
    
    func setup() {
        
        let anchor = AnchorEntity(.image(group: "AR Resources", name: "imac-21"))
        
        cancellable = Entity.loadModelAsync(named: "toy_drummer_idle")
            .sink { completion in
                switch completion {
                    case .failure(let error):
                        print("failure")
                    case .finished:
                        print("Loaded...")
                }
            } receiveValue: { [weak self] entity in
                entity.scale = [0.05, 0.05, 0.05]
                anchor.addChild(entity)
                self?.arView?.scene.addAnchor(anchor)
            }
        
       
        
    }
}

struct ARViewContainer: UIViewRepresentable {
    
    
    func makeUIView(context: Context) -> ARView {
        
        let arView = ARView(frame: .zero)
        
        context.coordinator.arView = arView
        context.coordinator.setup()
        
        return arView
        
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator()
    }
    
}

#Preview {
    ContentView()
}
